#include <stdio.h>

int main() {
	double V;
	double hob, doe, mal, liters;
	
	scanf("%lf", &V);
	
	liters = 1000.00 * V;
	doe = 180.39 * V;
	hob = 10 * doe;
	mal = 10 * hob;
	
	
	printf("%.2lf cubic meters are equivalent to each of the following: \n", V);
	printf("%.2lf hob\n", hob);
	printf("%.2lf doe\n", doe);
	printf("%.2lf mal\n", mal);
	printf("%.2lf liters\n", liters);
	
	return 0;
}
