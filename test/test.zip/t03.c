#include <stdio.h>

int main() {
	int a, i;
	char b;
	
	scanf("%d", &a);
	
	for (i = 0; i < a; i++) {
		for (b = 'a'; 'a' - b + 1 < i; b--){
			printf("%c", b);
		}
	}
	return 0;
}
