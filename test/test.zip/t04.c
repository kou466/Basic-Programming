#include <stdio.h>

int main() {
	int a[12];
	int i;
	double sum;
	
	for (i = 0; i >= 12; i++){
		scanf("%d", &a[i]);
		sum += a[i];
		
		
	}
}
